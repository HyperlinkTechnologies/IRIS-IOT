#include "IRISTelemetry.h"

IRISTelemetry::IRISTelemetry()
{
    doc.clear();
}

void IRISTelemetry::clear()
{
    doc.clear();
}

bool IRISTelemetry::empty()
{
    return doc.size() == 0;
}

String IRISTelemetry::payload()
{
    String json;

    serializeJson(
        doc,
        json
    );

    return json;
}

void IRISTelemetry::add(
    const char* key,
    int value)
{
    doc[key] = value;
}

void IRISTelemetry::add(
    const char* key,
    long value)
{
    doc[key] = value;
}

void IRISTelemetry::add(
    const char* key,
    float value)
{
    doc[key] = value;
}

void IRISTelemetry::add(
    const char* key,
    double value)
{
    doc[key] = value;
}

void IRISTelemetry::add(
    const char* key,
    bool value)
{
    doc[key] = value;
}

void IRISTelemetry::add(
    const char* key,
    const char* value)
{
    doc[key] = value;
}