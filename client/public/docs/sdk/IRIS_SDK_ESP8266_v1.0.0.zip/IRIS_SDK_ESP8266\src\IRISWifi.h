#ifndef IRIS_WIFI_H
#define IRIS_WIFI_H

#include <Arduino.h>

class IRISWiFi
{
public:

    IRISWiFi();

    bool begin(
        const char* ssid,
        const char* password
    );

    void loop();

    bool connected();
    
    int getRSSI();

    void disconnect();
    
private:

    const char* _ssid;
    const char* _password;

    void reconnect();
};

#endif