#include "IRISTime.h"

#include <time.h>

IRISTime::IRISTime()
{
}

bool IRISTime::begin()
{
    configTime(
        0,
        0,
        "pool.ntp.org",
        "time.nist.gov"
    );

    IRIS_LOG("Waiting for NTP time");

    time_t now = time(nullptr);

    while (now < 8 * 3600 * 2)
    {
        delay(500);
        IRIS_LOG(".");

        now = time(nullptr);
    }

    IRIS_LOG("Time synchronized");

    return true;
}