#ifndef IRIS_DEBUG_H
#define IRIS_DEBUG_H

#define IRIS_ENABLE_DEBUG

#ifdef IRIS_ENABLE_DEBUG

#define IRIS_LOG(x) \
    Serial.println(x)

#define IRIS_LOGF(x,v) \
    do { \
        Serial.print(x); \
        Serial.println(v); \
    } while(0)

#else

#define IRIS_LOG(x)
#define IRIS_LOGF(x,v)

#endif

#endif