# IRIS SDK for ESP8266

IRIS SDK for ESP8266 provides a simple way to connect ESP8266-based devices to the IRIS IoT Platform.

The SDK handles Wi-Fi connectivity, secure AWS IoT communication, telemetry publishing, and remote command handling.

## **Features**

- ESP8266 support
- Wi-Fi connectivity
- Secure AWS IoT communication
- MQTT telemetry publishing
- Remote command handling
- Device identification
- Automatic connection management
- Telemetry support for common Arduino data types

## **Requirements**

### **Hardware**

- ESP8266 development board
- Sensors and/or actuators as required by your application

### **Software**

- Arduino IDE
- ESP8266 board package
- IRIS SDK for ESP8266

## **Installation**

### **Arduino IDE**

1. Download the IRIS SDK for ESP8266 ZIP package.
2. Open Arduino IDE.
3. Select **Sketch → Include Library → Add .ZIP Library...**
4. Select the downloaded SDK ZIP file.
5. The IRIS library will be installed.

After installation, the examples are available under:

**File → Examples → IRIS**

## **Device Configuration**

Before uploading a sketch, create and configure the device in the IRIS IoT Platform.

You need:

- Wi-Fi SSID
- Wi-Fi password
- IRIS device ID

Configure the Wi-Fi credentials in your sketch:

```cpp
const char* ssid = "YOUR_WIFI";
const char* password = "YOUR_PASSWORD";
```

Initialize the IRIS SDK with your device ID:

```cpp
iris.begin(
    ssid,
    password,
    "YOUR_IRIS_DEVICE_ID"
);
```

Each physical device should use its own IRIS device ID.

## **Basic SDK Usage**

### **Include the SDK**

```cpp
#include <IRIS.h>

IRISClient iris;
```

### **Initialize the Device**

Initialize the IRIS SDK inside `setup()`:

```cpp
void setup()
{
    Serial.begin(115200);

    iris.begin(
        ssid,
        password,
        "YOUR_IRIS_DEVICE_ID"
    );
}
```

### **Keep Communication Active**

Call `iris.loop()` continuously from the Arduino `loop()` function:

```cpp
void loop()
{
    iris.loop();
}
```

## **Telemetry**

Telemetry values can be added using `addTelemetry()` and sent to the IRIS Platform using `publish()`.

### **Single Telemetry Value**

```cpp
int sensorValue = analogRead(A0);

iris.addTelemetry(
    "sensor",
    sensorValue
);

iris.publish();
```

### **Multiple Telemetry Values**

Multiple values can be added before publishing:

```cpp
iris.addTelemetry(
    "temperature",
    25.5
);

iris.addTelemetry(
    "humidity",
    60
);

iris.addTelemetry(
    "relay",
    true
);

iris.publish();
```

Telemetry keys and values are application-defined.

### **Supported Telemetry Types**

The SDK supports common Arduino data types, including:

- Integer
- Long
- Float
- Double
- Boolean
- String

Example:

```cpp
iris.addTelemetry("temperature", 25.5);
iris.addTelemetry("humidity", 60);
iris.addTelemetry("relay", true);
iris.addTelemetry("status", "active");
```

## **Command Handling**

The IRIS SDK supports commands sent from the IRIS Platform to the ESP8266 device.

### **Create a Command Callback**

```cpp
void handleCommand(
    String command,
    JsonVariant value
)
{
    if (command == "relay")
    {
        bool state = value.as<bool>();

        // Control hardware here
    }
}
```

### **Register the Callback**

```cpp
iris.onCommand(
    handleCommand
);
```

The callback receives:

| Parameter | Description |
|---|---|
| `command` | Command name |
| `value` | Command value |

### **Example: LED Control**

```cpp
void handleCommand(
    String command,
    JsonVariant value
)
{
    if (command == "led")
    {
        bool state = value.as<bool>();

        digitalWrite(
            LED_BUILTIN,
            state ? LOW : HIGH
        );
    }
}
```

Register the callback during setup:

```cpp
iris.onCommand(
    handleCommand
);
```

## **SDK API Reference**

### **`iris.begin()`**

Initializes the IRIS device and communication.

```cpp
iris.begin(
    ssid,
    password,
    "YOUR_IRIS_DEVICE_ID"
);
```

| Parameter | Description |
|---|---|
| `ssid` | Wi-Fi network name |
| `password` | Wi-Fi password |
| `deviceId` | IRIS device ID |

### **`iris.loop()`**

Maintains IRIS device communication.

```cpp
iris.loop();
```

Call this continuously from the Arduino `loop()` function.

### **`iris.addTelemetry()`**

Adds a telemetry value to the current telemetry payload.

```cpp
iris.addTelemetry(
    "temperature",
    25.5
);
```

Multiple telemetry values can be added before calling `publish()`.

### **`iris.publish()`**

Publishes the current telemetry payload to the IRIS Platform.

```cpp
iris.publish();
```

### **`iris.onCommand()`**

Registers the callback used to process commands received from the IRIS Platform.

```cpp
iris.onCommand(
    handleCommand
);
```

## **Complete Basic Example**

The following example demonstrates the basic SDK communication flow:

```cpp
#include <IRIS.h>

IRISClient iris;

unsigned long lastPublish = 0;

const char* ssid = "YOUR_WIFI";
const char* password = "YOUR_PASSWORD";

void handleCommand(
    String command,
    JsonVariant value
)
{
    Serial.println("===== COMMAND RECEIVED =====");

    Serial.print("Command: ");
    Serial.println(command);

    Serial.print("Value: ");
    Serial.println(value.as<bool>());
}

void setup()
{
    Serial.begin(115200);

    iris.begin(
        ssid,
        password,
        "YOUR_IRIS_DEVICE_ID"
    );

    iris.onCommand(
        handleCommand
    );

    Serial.println(
        "IRIS device initialized"
    );
}

void loop()
{
    iris.loop();

    if (millis() - lastPublish >= 5000)
    {
        lastPublish = millis();

        iris.addTelemetry(
            "temperature",
            25.5
        );

        iris.addTelemetry(
            "humidity",
            60
        );

        iris.publish();

        Serial.println(
            "Telemetry published"
        );
    }
}
```

## **Included Examples**

The SDK includes the following Arduino examples.

### **TelemetryTest**

Demonstrates:

- Device initialization
- Wi-Fi connection
- Telemetry publishing
- Command handling
- Command state reporting

Use this example first to verify communication between the ESP8266 and the IRIS Platform.

**Open:** `File → Examples → IRIS → TelemetryTest`

### **CommandTest**

Demonstrates receiving a command from the IRIS Platform and controlling an ESP8266 output.

**Open:** `File → Examples → IRIS → CommandTest`

### **RelayControl**

Demonstrates remote relay control using an IRIS command.

**Open:** `File → Examples → IRIS → RelayControl`

### **ServoControl**

Demonstrates remote servo control using an IRIS command.

**Open:** `File → Examples → IRIS → ServoControl`

## **Recommended First Test**

After installing the SDK:

1. Register a device in the IRIS Platform.
2. Copy the device ID.
3. Open **TelemetryTest**.
4. Enter your Wi-Fi credentials.
5. Enter your IRIS device ID.
6. Select your ESP8266 board.
7. Select the correct serial port.
8. Upload the sketch.
9. Open Serial Monitor at **115200 baud**.
10. Verify that telemetry appears in the IRIS Platform.
11. Test command handling from the IRIS Platform.

## **Troubleshooting**

### **Device Does Not Connect**

Check:

- Wi-Fi SSID
- Wi-Fi password
- IRIS device ID
- ESP8266 board selection
- Serial port
- Serial Monitor output

### **Telemetry Does Not Appear**

Make sure the sketch continuously calls:

```cpp
iris.loop();
```

and publishes telemetry using:

```cpp
iris.publish();
```

Also verify that the device is registered in the IRIS Platform.

### **Commands Are Not Received**

Make sure a command callback is registered:

```cpp
iris.onCommand(
    handleCommand
);
```

Also make sure:

```cpp
iris.loop();
```

continues running inside `loop()`.

### **Arduino Cannot Find the IRIS Library**

Reinstall the SDK using:

**Sketch → Include Library → Add .ZIP Library...**

Then check:

**File → Examples → IRIS**

## **Supported Platform**

The current SDK supports:

- ESP8266

## **Folder Structure**

```text
IRIS_SDK_ESP8266/
│
├── examples/
│   ├── CommandTest/
│   │   └── CommandTest.ino
│   ├── RelayControl/
│   │   └── RelayControl.ino
│   ├── ServoControl/
│   │   └── ServoControl.ino
│   └── TelemetryTest/
│       └── TelemetryTest.ino
│
├── src/
│   ├── IRIS.cpp
│   ├── IRIS.h
│   ├── IRISCertificates.h
│   ├── IRISCommand.h
│   ├── IRISConfig.h
│   ├── IRISDebug.h
│   ├── IRISMQTT.cpp
│   ├── IRISMQTT.h
│   ├── IRISStatus.h
│   ├── IRISTelemetry.cpp
│   ├── IRISTelemetry.h
│   ├── IRISTime.cpp
│   ├── IRISTime.h
│   ├── IRISVersion.h
│   ├── IRISWifi.cpp
│   └── IRISWifi.h
│
├── keywords.txt
├── library.properties
├── LICENSE
└── README.md
```

## **License**

Copyright © Hyperlink Technologies.

See the `LICENSE` file included with the SDK for license information.
