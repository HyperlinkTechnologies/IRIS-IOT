#include "IRISMQTT.h"

#include "IRISConfig.h"
#include "IRISCertificates.h"
#include "IRISDebug.h"

IRISMQTT* IRISMQTT::instance = nullptr;

IRISMQTT::IRISMQTT()
    : mqttClient(secureClient)
{
}

bool IRISMQTT::begin(
    const char* deviceId)
{
    _deviceId = deviceId;

    instance = this;

    static BearSSL::X509List ca(IRIS_ROOT_CA);
    static BearSSL::X509List cert(IRIS_DEVICE_CERT);
    static BearSSL::PrivateKey key(IRIS_PRIVATE_KEY);

    secureClient.setTrustAnchors(&ca);

    secureClient.setClientRSACert(
        &cert,
        &key
    );

    mqttClient.setServer(
        IRIS_AWS_ENDPOINT,
        IRIS_MQTT_PORT
    );

    mqttClient.setCallback(
        mqttDispatcher
    );

    reconnect();

    return true;
}

void IRISMQTT::reconnect()
{
    while (!mqttClient.connected())
    {
        IRIS_LOG("Connecting to MQTT...");

        IRIS_LOGF("Endpoint: ", IRIS_AWS_ENDPOINT);

        IRIS_LOGF("Client ID: ", _deviceId);

        if (mqttClient.connect(_deviceId))
        {
            IRIS_LOG("MQTT Connected");

            subscribe(
                IRIS_COMMAND_TOPIC(_deviceId).c_str()
            );
        }
        else
        {
            IRIS_LOGF("MQTT Failed: ", mqttClient.state());

            delay(IRIS_RECONNECT_DELAY);
        }
    }
}

void IRISMQTT::loop()
{
    if(!connected())
    {
        reconnect();
    }

    mqttClient.loop();
}

bool IRISMQTT::connected()
{
    return mqttClient.connected();
}

bool IRISMQTT::publish(
    const char* topic,
    const char* payload)
{
    return mqttClient.publish(
        topic,
        payload
    );
}

void IRISMQTT::subscribe(
    const char* topic)
{
    mqttClient.subscribe(topic);
}

void IRISMQTT::setCommandCallback(
    IRISCommandCallback callback)
{
    commandCallback = callback;
}

void IRISMQTT::mqttDispatcher(
    char* topic,
    byte* payload,
    unsigned int length)
{
    if(instance)
    {
        instance->mqttCallback(
            topic,
            payload,
            length
        );
    }
}

void IRISMQTT::mqttCallback(
    char* topic,
    byte* payload,
    unsigned int length)
{
    StaticJsonDocument<IRIS_COMMAND_BUFFER_SIZE> doc;

    if(deserializeJson(
        doc,
        payload,
        length))
    {
        return;
    }

    Serial.println("===== COMMAND RECEIVED =====");
serializeJson(doc, Serial);
Serial.println();

    if(commandCallback)
    {
        commandCallback(
    doc["command"],
    doc["payload"]["value"]
);
    }
}