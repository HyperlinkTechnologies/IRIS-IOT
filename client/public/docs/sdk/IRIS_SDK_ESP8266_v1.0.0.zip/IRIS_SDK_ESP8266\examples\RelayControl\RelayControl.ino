#include <IRIS.h>

IRISClient iris;

const char* ssid = "YOUR_WIFI";
const char* password = "YOUR_PASSWORD";

#define RELAY_PIN D1

void commandHandler(String command, JsonVariant value)
{
    if(command=="relay")
    {
        digitalWrite(
            RELAY_PIN,
            value.as<bool>()
        );
    }
}

void setup()
{
    pinMode(RELAY_PIN,OUTPUT);

    iris.begin(
        ssid,
        password,
        "YOUR_IRIS_DEVICE_ID"
    );

    iris.onCommand(
        commandHandler
    );
}

void loop()
{
    iris.loop();
}