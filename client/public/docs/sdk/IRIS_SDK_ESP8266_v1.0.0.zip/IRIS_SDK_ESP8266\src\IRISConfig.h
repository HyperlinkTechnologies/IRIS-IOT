#ifndef IRIS_CONFIG_H
#define IRIS_CONFIG_H

#include <Arduino.h>

/*----------------------------------------------------------
    IRIS SDK for ESP8266 Configuration
----------------------------------------------------------*/

//==================== AWS IoT ====================//

#define IRIS_AWS_ENDPOINT "a2ponnfb89vi21-ats.iot.us-east-1.amazonaws.com"

#define IRIS_MQTT_PORT 8883

//==================== Topics ====================//

inline String IRIS_TELEMETRY_TOPIC(const char* deviceId)
{
    return "iris/" +
           String(deviceId) +
           "/telemetry";
}

inline String IRIS_COMMAND_TOPIC(const char* deviceId)
{
    return "iris/" +
           String(deviceId) +
           "/command";
}

//==================== SDK ====================//

#define IRIS_TELEMETRY_BUFFER_SIZE 512

#define IRIS_COMMAND_BUFFER_SIZE 256

#define IRIS_RECONNECT_DELAY 2000

#endif