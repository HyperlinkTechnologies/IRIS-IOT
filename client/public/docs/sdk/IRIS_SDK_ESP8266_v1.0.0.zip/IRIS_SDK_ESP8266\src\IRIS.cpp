#include "IRIS.h"
#include "IRISConfig.h"
#include <time.h>

IRISClient::IRISClient()
{
}

bool IRISClient::begin(
    const char* ssid,
    const char* password,
    const char* deviceId)
{
    _deviceId = deviceId;

wifi.begin(
    ssid,
    password
);

time.begin();

mqtt.begin(
    _deviceId
);

    return true;
}

void IRISClient::loop()
{
    wifi.loop();

    mqtt.loop();
}

bool IRISClient::connected()
{
    return
        wifi.connected() &&
        mqtt.connected();
}

bool IRISClient::publish()
{
    if (telemetry.empty())
    {
        return false;
    }

    telemetry.add("deviceId", _deviceId);
telemetry.add("rssi", wifi.getRSSI());
telemetry.add("uptime", static_cast<long>(millis() / 1000));

    String topic = IRIS_TELEMETRY_TOPIC(_deviceId);

    if (mqtt.publish(topic.c_str(), telemetry.payload().c_str()))
    {
        telemetry.clear();
        return true;
    }

    return false;
}

void IRISClient::onCommand(
    IRISCommandCallback callback)
{
    mqtt.setCommandCallback(callback);
}

void IRISClient::addTelemetry(const char* key,int value)
{
    telemetry.add(key,value);
}

void IRISClient::addTelemetry(const char* key,long value)
{
    telemetry.add(key,value);
}

void IRISClient::addTelemetry(const char* key,float value)
{
    telemetry.add(key,value);
}

void IRISClient::addTelemetry(const char* key,double value)
{
    telemetry.add(key,value);
}

void IRISClient::addTelemetry(const char* key,bool value)
{
    telemetry.add(key,value);
}

void IRISClient::addTelemetry(const char* key,const char* value)
{
    telemetry.add(key,value);
}

void IRISClient::addTelemetry(
    const String& key,
    const String& value)
{
    telemetry.add(
        key.c_str(),
        value.c_str()
    );
}