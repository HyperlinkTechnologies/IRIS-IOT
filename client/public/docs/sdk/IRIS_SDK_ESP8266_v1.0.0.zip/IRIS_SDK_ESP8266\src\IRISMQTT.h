#ifndef IRIS_MQTT_H
#define IRIS_MQTT_H

#include <Arduino.h>
#include <PubSubClient.h>
#include <WiFiClientSecureBearSSL.h>

#include "IRISCommand.h"

class IRISMQTT
{
public:

    IRISMQTT();

    bool begin(
        const char* deviceId
    );

    void loop();

    bool connected();

    bool publish(
        const char* topic,
        const char* payload
    );

    void subscribe(
        const char* topic
    );

    void setCommandCallback(
        IRISCommandCallback callback
    );

private:

    BearSSL::WiFiClientSecure secureClient;

    PubSubClient mqttClient;

    const char* _deviceId;

    IRISCommandCallback commandCallback = nullptr;

    static IRISMQTT* instance;

    void reconnect();

    static void mqttDispatcher(
        char* topic,
        byte* payload,
        unsigned int length
    );

    void mqttCallback(
        char* topic,
        byte* payload,
        unsigned int length
    );
};

#endif