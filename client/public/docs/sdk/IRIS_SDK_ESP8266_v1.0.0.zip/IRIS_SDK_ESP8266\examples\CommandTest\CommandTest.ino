#include <IRIS.h>

IRISClient iris;

const char* ssid = "YOUR_WIFI";
const char* password = "YOUR_PASSWORD";

#define LED_PIN LED_BUILTIN

void commandHandler(String command, JsonVariant value)
{
    Serial.println("========== COMMAND RECEIVED ==========");
    Serial.print("Command : ");
    Serial.println(command);

    Serial.print("Value   : ");
    Serial.println(value.as<String>());

    if (command == "relay")
    {
        bool state = value.as<bool>();

        digitalWrite(LED_PIN, state ? LOW : HIGH);

        Serial.println(state ? "Relay ON" : "Relay OFF");
    }
}

void setup()
{
    Serial.begin(115200);

    pinMode(LED_PIN, OUTPUT);
    digitalWrite(LED_PIN, HIGH);

    iris.begin(
        ssid,
        password,
        "YOUR_IRIS_DEVICE_ID"
    );

    iris.onCommand(commandHandler);

    Serial.println("Waiting for commands...");
}

void loop()
{
    iris.loop();
}