#include <IRIS.h>
#include <Servo.h>

IRISClient iris;

Servo servo;

const char* ssid="YOUR_WIFI";
const char* password="YOUR_PASSWORD";

void commandHandler(
    String command,
    JsonVariant value)
{
    if(command=="servo")
    {
        servo.write(
            value.as<int>()
        );
    }
}

void setup()
{
    servo.attach(D4);

    iris.begin(
        ssid,
        password,
        "YOUR_IRIS_DEVICE_ID"
    );

    iris.onCommand(
        commandHandler
    );
}

void loop()
{
    iris.loop();
}