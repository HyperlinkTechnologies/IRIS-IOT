#ifndef IRIS_TELEMETRY_H
#define IRIS_TELEMETRY_H

#include "IRISConfig.h"
#include <Arduino.h>
#include <ArduinoJson.h>

class IRISTelemetry
{
public:

    IRISTelemetry();

    void clear();

    bool empty();

    String payload();

    void add(const char* key, int value);
    void add(const char* key, long value);
    void add(const char* key, float value);
    void add(const char* key, double value);
    void add(const char* key, bool value);
    void add(const char* key, const char* value);

private:

    StaticJsonDocument<IRIS_TELEMETRY_BUFFER_SIZE> doc;
};

#endif