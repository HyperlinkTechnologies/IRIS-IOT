#ifndef IRIS_COMMAND_H
#define IRIS_COMMAND_H

#include <ArduinoJson.h>

typedef void (*IRISCommandCallback)(
    String command,
    JsonVariant value
);

#endif