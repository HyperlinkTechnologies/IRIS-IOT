#include "IRISWiFi.h"

#include <ESP8266WiFi.h>
#include "IRISDebug.h"

IRISWiFi::IRISWiFi()
{
}

bool IRISWiFi::begin(
    const char* ssid,
    const char* password)
{
    _ssid = ssid;
    _password = password;

    WiFi.mode(WIFI_STA);
    IRIS_LOG("Connecting to WiFi...");

    WiFi.begin(_ssid, _password);

    while (!connected())
    {
        IRIS_LOG(".");
        delay(500);
    }

    IRIS_LOG("WiFi Connected");
    IRIS_LOGF("IP: ", WiFi.localIP());


    
    return true;
}

void IRISWiFi::loop()
{
    if (!connected())
    {
        reconnect();
    }
}

bool IRISWiFi::connected()
{
    return WiFi.status() == WL_CONNECTED;
}

int IRISWiFi::getRSSI()
{
    return WiFi.RSSI();
}

void IRISWiFi::disconnect()
{
    WiFi.disconnect(true);
}

void IRISWiFi::reconnect()
{
    WiFi.disconnect();

    WiFi.begin(
        _ssid,
        _password
    );

    while (!connected())
    {
        delay(500);
    }
}