#ifndef IRIS_TIME_H
#define IRIS_TIME_H

#include <Arduino.h>
#include "IRISDebug.h"

class IRISTime
{
public:

    IRISTime();

    bool begin();
};

#endif