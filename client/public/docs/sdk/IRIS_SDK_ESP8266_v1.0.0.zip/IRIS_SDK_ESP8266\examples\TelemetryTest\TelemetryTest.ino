#include <IRIS.h>

IRISClient iris;
unsigned long lastPublish = 0;

const char* ssid = "YOUR_WIFI";
const char* password = "YOUR_PASSWORD";

float temperature = 25.5;
int humidity = 30;
bool relay = false;

void handleCommand(String command, JsonVariant value)
{
    Serial.println("===== CALLBACK =====");
    Serial.print("Command: ");
    Serial.println(command);

    Serial.print("Value: ");
    Serial.println(value.as<bool>());

    if (command == "relay")
    {
        relay = value.as<bool>();
        iris.addTelemetry("relay", relay);
        iris.publish();
    }
}

void setup()
{
    Serial.begin(115200);

    iris.begin(
        ssid,
        password,
        "YOUR_IRIS_DEVICE_ID"
    );
    iris.onCommand(handleCommand);
    Serial.println("Telemetry Test Started");
}

void loop()
{
    iris.loop();

    if (millis() - lastPublish >= 5000)
    {
        lastPublish = millis();

        temperature += 0.2;
        humidity++;

        iris.addTelemetry("temperature", temperature);
        iris.addTelemetry("humidity", humidity);
        iris.addTelemetry("relay", relay);

        iris.publish();

        Serial.println("Telemetry Publish Requested");
    }
}