#ifndef IRIS_STATUS_H
#define IRIS_STATUS_H

enum IRISStatus
{
    IRIS_OK,

    IRIS_WIFI_FAILED,

    IRIS_NTP_FAILED,

    IRIS_MQTT_FAILED,

    IRIS_PUBLISH_FAILED
};

#endif