#ifndef IRIS_H
#define IRIS_H

#include <Arduino.h>

#include "IRISWiFi.h"
#include "IRISMQTT.h"
#include "IRISTelemetry.h"
#include "IRISCommand.h"
#include "IRISTime.h"


class IRISClient
{
public:

    IRISClient();

    bool begin(
        const char* ssid,
        const char* password,
        const char* deviceId
    );

    void loop();

    bool connected();

    bool publish();

    void onCommand(
        IRISCommandCallback callback
    );

    void addTelemetry(const char* key, int value);
    void addTelemetry(const char* key, long value);
    void addTelemetry(const char* key, float value);
    void addTelemetry(const char* key, double value);
    void addTelemetry(const char* key, bool value);
    void addTelemetry(const char* key, const char* value);
    void addTelemetry(const String& key, const String& value);

private:

    IRISWiFi wifi;

    IRISTime time;

    IRISMQTT mqtt;

    IRISTelemetry telemetry;

    const char* _deviceId;
};

#endif